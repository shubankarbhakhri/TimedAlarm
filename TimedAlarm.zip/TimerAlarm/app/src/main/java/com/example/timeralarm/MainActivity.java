package com.example.timeralarm;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    SeekBar seekBar;
    CountDownTimer count;
    public void stop(View v)
    {
        count.cancel();
        seekBar.setEnabled(true);
        int s = seekBar.getProgress();
        seekBar.setProgress(s);
        Toast.makeText(this,"progress is "+s,Toast.LENGTH_SHORT).show();
    }
    public void go(View v) {
        seekBar.setEnabled(false);
        Toast.makeText(this,"progres in go is"+seekBar.getProgress(),Toast.LENGTH_SHORT).show();
         count = new CountDownTimer(seekBar.getProgress()*1000+100, 1000) {

            @Override
            public void onTick(long l) {

                timeupdate(((int) l)/1000);
                seekBar.setProgress((int)l/1000);
            }
            public void onFinish() {
                MediaPlayer media = MediaPlayer.create(getApplicationContext(),R.raw.alarm);
                media.start();
            }
        }.start();
    }

        public void timeupdate(int progress){
            int min = progress/60;
            int sec = progress-(min*60);
            String sec2 = Integer.toString(sec);
            if(sec<=9)
            {
                sec2="0"+sec;
            }

            textView.setText(Integer.toString(min)+":"+sec2);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         seekBar = findViewById(R.id.seekBar);
         textView = findViewById(R.id.textView);
        seekBar.setMax(600);
        seekBar.setProgress(30);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                timeupdate(progress);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}
